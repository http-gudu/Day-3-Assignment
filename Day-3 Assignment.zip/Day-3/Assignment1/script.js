// Function to generate a random color
function getRandomColor() {
    var letters = '0123456789ABCDEF';
    var color = '#';
    for (var i = 0; i < 6; i++) {
        color += letters[Math.floor(Math.random() * 16)];
    }
    return color;
}

// Function to change the background color
function changeBackgroundColor() {
    var randomColor = getRandomColor();
    document.body.style.backgroundColor = randomColor;
}

// Add onclick event to change background color on click
document.onclick = function() {
    changeBackgroundColor();
};
